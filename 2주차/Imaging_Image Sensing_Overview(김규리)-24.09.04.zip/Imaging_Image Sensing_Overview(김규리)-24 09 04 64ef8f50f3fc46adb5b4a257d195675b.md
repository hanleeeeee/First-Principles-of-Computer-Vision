# Imaging_Image Sensing_Overview(김규리)-24.09.04

생성일: 2024년 9월 3일 오후 3:09

Image formation에서 optical image에 대한 내용을 다룸

→ Optical Images를  Digital Images로 변환하는 방법의 이해가 필요함

topics

1.  **A Brief Histroy of Imaging**

-오늘날의 카메라를 있게한 주요한 발명들(아날로그→디지털 전환의 핵심인 ‘이미지 센서’ 다룸)

1.  **Types of Image Sensors**

-이미지 센서의 두종류: CCD sensors vs CMOS sensors

1.  **Resolution, Noise, Dynamic Range**

-이미지 센서의 특징들을 다룸

-Noise: 노이즈 발생의 다양한 종류

-Dynamic Range(동적 범위): 이미지 센서가 측정할 수 있는 밝기 값의 범위

- 이미지 센서가 측정할 수 있는 최대 밝기와 최소 밝기의 차이
- 동적 범위가 넓을수록 한 장의 이미지에서 매우 어두운 영역과 매우 밝은 영역을 모두 세부적으로 표현 가능

1. **Sensing Color**

-이미지 센서가 색을 포착하는 방법

> Color is really human response to wavelength
> 

1. **Camera Response and HDR Imaging**

-Camera response function 설명

- 실제 장면의 밝기(아날로그)와  이미지에서의 밝기(디지털)의 변환 관계를 설명하는 함수임
- 실제 장면의 밝기가 있고 카메라 이미지에서의 밝기가 있음.
- 빛이 많아 밝을수록 이미지도 밝아지는 것이 맞기는 하나, 완전히 선형적인 관계는 아님

-HDR(high dynamic range imaging), 동적범위가 제한된 이미지 센서로 더 넓은 범위의 이미지 찍는 법

<aside>
💡

review: 동적범위란? 이미지 센서가 측정할 수 있는 밝기 값의 범위

</aside>

- 이미지 센서가 감지할 수 있는 밝기 영역을 벗어난 장면을 찍으면 다음과 같은 현상이 발생
    1. 밝은 부분의 과도한 노출: 센서가 인식할 수 있는 최대 밝기 벗어나면 이미지가 하얗게 날아감(지나치게 밝게 표현됨)
    2. 어두운 부분의 부족한 노출: :센서가 인식할 수 있는 최소 밝기 벗어나면 이미지가 검게 표현됨(지나치게 어둡게 표현됨)
- HDR은 일반적인 디지털 사진의 한계를 보완함.이미지에서 밝은 부분과 어두운 부분의 디테일을 동시에 표현하기 위해 사용되는 기술임
- 동일한 장면을 서로 다른 노출 설정으로 촬영하여 최적의 부분만을 결합하여 하나의 이미지를 만들어냄
    
    (노출을 달리하면 개별 사진의 동적 범위 자체는 달라지지 않지만 특정 노출에서 더 잘 표현되는 밝은 부분 또는 어두운 부분이 달라짐!)
    
1. **Nature’s Image Sensors**

-자연의 생물들이 세상을 보는법

-사람 눈의 망막에 대한 설명

-